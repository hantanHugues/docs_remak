
import time
from search import astar_search  # Assure-toi que astar_search renvoie (solution_node, nodes_explored)
from robot_search import RobotSolving, GridAccessor 

def main():
    # Exemple de matrice : 0 = libre, 1 = obstacle.
    # Remplace par la matrice fournie par l’équipe carte/coordonnées.
    matrix = [
        [0, 0, 0, 1, 0],
        [0, 1, 1, 1, 0],
        [0, 0, 0, 0, 0],
        [0, 1, 1, 1, 0],
        [0, 0, 0, 0, 0],
    ]
    # Créer l'accessoir de grille
    accessor = GridAccessor(matrix)

    # Définir état initial et but (tu peux les récupérer dynamiquement ou via arguments)
    initial = (0, 0)
    goal = (4, 4)

    # Instancier le problème
    try:
        problem = RobotSolving(initial, goal, accessor)
    except ValueError as e:
        print(f"Erreur lors de la création du problème : {e}")
        return

    # Lancer la recherche A*
    start_time = time.time()
    try:
        solution_node, nodes_explored = astar_search(problem)
    except Exception as e:
        print(f"Erreur pendant astar_search: {e}")
        return
    elapsed = time.time() - start_time

    # Traiter le résultat
    if solution_node is not None:
        # On suppose que solution_node.path() renvoie la liste de nœuds depuis l'initial jusqu'au but
        path_nodes = solution_node.path()
        path_states = [node.state for node in path_nodes]
        print("Chemin trouvé (liste d’états (x,y)) :")
        for idx, state in enumerate(path_states):
            print(f"  Étape {idx}: {state}")
        print(f"Nombre de nœuds explorés par A*: {nodes_explored}")
        print(f"Temps de calcul A*: {elapsed:.4f} s")
    else:
        print("A* n'a pas trouvé de chemin.")
        print(f"Nombre de nœuds explorés par A*: {nodes_explored}")
        print(f"Temps de calcul A*: {elapsed:.4f} s")

if __name__ == "__main__":
    main()
