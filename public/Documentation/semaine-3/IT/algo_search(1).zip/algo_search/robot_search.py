# robot_solving.py

from search import Problem, astar_search  # Assure-toi que search.Problem et search.Node (pour astar_search) sont accessibles
import math
from typing import Tuple, List, Any

class GridAccessor:
    """
    Exemple d'interface pour accéder à la grille issue de l’OccupancyGrid.
    La matrice doit être une liste de listes (ou équivalent) de valeurs où 0 = libre, !=0 = obstacle.
    is_free(state) renvoie False si hors-borne ou obstacle.
    """
    def __init__(self, matrix: List[List[int]]):
        """
        matrix: 2D list where 0 indicates free cell, non-zero indicates obstacle.
        """
        self.matrix = matrix
        self.height = len(matrix)
        self.width = len(matrix[0]) if self.height > 0 else 0

    def is_free(self, state: Tuple[int, int]) -> bool:
        """
        Retourne True si state=(x,y) est dans les bornes et la cellule est libre (matrix[y][x] == 0).
        """
        x, y = state
        if 0 <= x < self.width and 0 <= y < self.height:
            return self.matrix[y][x] == 0
        return False


class RobotSolving(Problem):
    """
    Problème de pathfinding sur grille avec 8-connexité.
    - État: tuple (x, y) indices de la cellule.
    - grid_accessor: objet fournissant is_free(state: Tuple[int,int]) -> bool.
    - goal: tuple (x, y) de la cellule cible.
    """

    def __init__(self, initial: Tuple[int, int], goal: Tuple[int, int], grid_accessor: Any):
        """
        initial: état initial (x, y)
        goal: état but (x, y)
        grid_accessor: objet avec méthode is_free(state) -> bool
        """
        # Vérification initial/goal libres peut être faite avant
        super().__init__(initial, goal)
        # Vérifier si initial et goal sont libres (optionnel mais recommandé)
        if not grid_accessor.is_free(initial):
            raise ValueError(f"État initial {initial} est sur une cellule occupée ou hors bornes.")
        if not grid_accessor.is_free(goal):
            raise ValueError(f"État but {goal} est sur une cellule occupée ou hors bornes.")
        self.grid = grid_accessor

        # Offsets pour 8-connexité
        self._offsets = [
            (-1, -1), (0, -1), (1, -1),
            (-1,  0),          (1,  0),
            (-1,  1), (0,  1), (1,  1)
        ]

    def actions(self, state: Tuple[int, int]) -> List[Tuple[int, int]]:
        """
        Retourne la liste des états voisins accessibles depuis l'état courant selon 8-connexité,
        en filtrant les obstacles et en évitant le "corner cutting".
        Chaque action est représentée directement par l'état voisin absolu (x', y').
        """
        x, y = state
        neighbors: List[Tuple[int, int]] = []
        for dx, dy in self._offsets:
            new_state = (x + dx, y + dy)
            # Vérifier que la cellule cible est libre
            if not self.grid.is_free(new_state):
                continue
            # Si déplacement diagonal, éviter de couper un coin entre deux obstacles
            if abs(dx) == 1 and abs(dy) == 1:
                # Pour aller en diagonal, au moins une des deux cellules orthogonales adjacentes doit être libre
                state1 = (x + dx, y)
                state2 = (x, y + dy)
                if not (self.grid.is_free(state1) or self.grid.is_free(state2)):
                    continue
            neighbors.append(new_state)
        return neighbors

    def result(self, state: Tuple[int, int], action: Tuple[int, int]) -> Tuple[int, int]:
        """
        action est directement l'état voisin (x', y'), on retourne donc action.
        """
        return action

    def goal_test(self, state: Tuple[int, int]) -> bool:
        """
        Test de but: True si l'état correspond à la cellule but.
        """
        return state == self.goal

    def path_cost(self, cost_so_far: float, state1: Tuple[int, int],
                  action: Tuple[int, int], state2: Tuple[int, int]) -> float:
        """
        Coût du mouvement: 1 pour mouvements orthogonaux, sqrt(2) pour diagonaux.
        Ici, state2 doit être égal à action (voisin absolu).
        """
        # Optionnel: assertion pour debug, commente ou retire en prod si inutile
        # assert state2 == action
        dx = abs(state2[0] - state1[0])
        dy = abs(state2[1] - state1[1])
        # Si dx==1 et dy==1 => diagonal
        if dx == 1 and dy == 1:
            return cost_so_far + math.sqrt(2)
        else:
            # dx+dy == 1 pour mouvement orthogonal
            return cost_so_far + 1.0

    def h(self, node) -> float:
        """
        Heuristique pour A*: distance octile entre node.state et goal.
        node.state est un tuple (x, y). 
        On suppose que astar_search appellera problem.h(node).
        """
        x, y = node.state
        gx, gy = self.goal
        dx = abs(x - gx)
        dy = abs(y - gy)
        # Distance octile: max(dx, dy) + (sqrt(2)-1)*min(dx, dy)
        return max(dx, dy) + (math.sqrt(2) - 1) * min(dx, dy)

    def is_deadlock(self, state: Tuple[int, int]) -> bool:
        """
        Méthode optionnelle : renvoie True si l'état est un deadlock (pas d'actions possibles) et n'est pas le but.
        Pour un pathfinding simple, on n'a pas forcément besoin de l'appeler dans l'algorithme,
        car un état sans voisins sera naturellement ignorable par A*.
        """
        if self.goal_test(state):
            return False
        return len(self.actions(state)) == 0





